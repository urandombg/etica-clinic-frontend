<template>
<v-container>
  <h1>
    Create new User
  </h1>
</v-container>
</template>

<script>
export default {
name: "CreateNewUser"
}
</script>

<style scoped>

</style>
