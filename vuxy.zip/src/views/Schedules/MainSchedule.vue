<template>

</template>

<script>
export default {
  name: "MainSchedule"
}
</script>

<style scoped>

</style>