<template>
<div>

</div>
</template>

<script>
export default {
  name: 'InvoiceFooter',
  props: {
    InvoiceRecepient: String,
    isValid: String,
    invoiceCreator: String
  }
}
</script>

<style scoped>

</style>
